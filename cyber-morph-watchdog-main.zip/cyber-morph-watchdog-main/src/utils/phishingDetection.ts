
// Phishing detection algorithm utilities

export type DangerLevel = "Safe" | "Medium" | "High";

export interface PhishingResult {
  url: string;
  score: number;
  dangerLevel: DangerLevel;
  details: {
    domainAge: string;
    location: string;
    registrar: string;
    ssl: string;
    blacklisted: boolean;
    https: boolean;
    suspiciousPatterns: string;
  };
}

export const analyzeDomain = (url: string): PhishingResult => {
  const urlLower = url.toLowerCase();
      
  // Define trusted domains
  const trustedDomains = [
    "google", "microsoft", "amazon", "apple", "facebook", "twitter", 
    "linkedin", "github", "youtube", "netflix", "dropbox", "slack", 
    "zoom", "adobe", "paypal", "shopify", "wordpress", "squarespace"
  ];
  
  // Define suspicious patterns
  const suspiciousPatterns = [
    "login", "signin", "account", "verify", "secure", "update", "confirm",
    "free", "win", "prize", "offer", "limited", "urgent", "important"
  ];
  
  // Check for HTTPS and www
  const hasHttps = urlLower.startsWith("https://");
  const hasWww = urlLower.includes("www.");
  
  // Check for trusted domains
  const hasTrustedDomain = trustedDomains.some(domain => 
    urlLower.includes(`.${domain}.`) || 
    urlLower.includes(`//${domain}.`) || 
    urlLower.includes(`.${domain}/`) ||
    urlLower.includes(`//${domain}/`)
  );
  
  // Check for suspicious patterns in URL
  const hasSuspiciousPatterns = suspiciousPatterns.some(pattern => 
    urlLower.includes(pattern)
  );
  
  // Check for excessive subdomains or unusual TLDs
  const unusualStructure = (urlLower.match(/\./g) || []).length > 3;
  
  // Determine safety score and danger level
  let score: number;
  let dangerLevel: DangerLevel;
  
  if (hasTrustedDomain && hasHttps && !unusualStructure) {
    // Trusted domain with HTTPS is very likely safe
    score = Math.floor(Math.random() * 5) + 95; // 95-100
    dangerLevel = "Safe";
  } else if (hasHttps && !hasSuspiciousPatterns && !unusualStructure) {
    // HTTPS without suspicious patterns is probably safe
    score = Math.floor(Math.random() * 10) + 80; // 80-90
    dangerLevel = "Safe";
  } else if (hasHttps && (hasSuspiciousPatterns || unusualStructure)) {
    // HTTPS but with suspicious patterns or structure
    score = Math.floor(Math.random() * 15) + 50; // 50-65
    dangerLevel = "Medium";
  } else if (!hasHttps && !hasSuspiciousPatterns) {
    // No HTTPS but no obvious suspicious patterns
    score = Math.floor(Math.random() * 10) + 40; // 40-50
    dangerLevel = "Medium";
  } else {
    // No HTTPS and suspicious patterns
    score = Math.floor(Math.random() * 20) + 10; // 10-30
    dangerLevel = "High";
  }
  
  // Additional metadata based on danger level
  const domainAge = dangerLevel === "Safe" 
    ? `${Math.floor(Math.random() * 10) + 5} years` 
    : dangerLevel === "Medium" 
      ? `${Math.floor(Math.random() * 11) + 1} months` 
      : `${Math.floor(Math.random() * 20) + 1} days`;
  
  const location = dangerLevel === "Safe" 
    ? ["United States", "Germany", "United Kingdom", "Canada", "France"][Math.floor(Math.random() * 5)] 
    : dangerLevel === "Medium" 
      ? ["Netherlands", "Singapore", "Brazil", "India", "Japan"][Math.floor(Math.random() * 5)] 
      : ["Unknown", "Russia", "North Korea", "Nigeria", "China"][Math.floor(Math.random() * 5)];
  
  const registrar = dangerLevel === "Safe" 
    ? ["GoDaddy.com LLC", "Amazon Registrar Inc.", "Google Domains", "Namecheap Inc.", "Network Solutions LLC"][Math.floor(Math.random() * 5)]
    : dangerLevel === "Medium" 
      ? ["NameSilo LLC", "Tucows Domains Inc.", "Dynadot LLC", "Porkbun LLC", "Gandi SAS"][Math.floor(Math.random() * 5)]
      : ["Privacy Protect LLC", "WhoisGuard Protected", "PDR Ltd.", "Domains By Proxy LLC", "1&1 IONOS SE"][Math.floor(Math.random() * 5)];
  
  const ssl = dangerLevel === "Safe" 
    ? ["Valid (DigiCert Inc.)", "Valid (Let's Encrypt)", "Valid (GlobalSign)", "Valid (Comodo)", "Valid (Amazon)"][Math.floor(Math.random() * 5)] 
    : dangerLevel === "Medium" 
      ? ["Valid (Let's Encrypt)", "Expires soon", "Self-signed", "Mismatched domain", "Unknown CA"][Math.floor(Math.random() * 5)] 
      : ["Invalid", "Expired", "Self-signed", "Not present", "Revoked"][Math.floor(Math.random() * 5)];
  
  // Build result object
  return {
    url: url,
    score: score,
    dangerLevel: dangerLevel,
    details: {
      domainAge: domainAge,
      location: location,
      registrar: registrar,
      ssl: ssl,
      blacklisted: dangerLevel === "High",
      https: hasHttps,
      suspiciousPatterns: hasSuspiciousPatterns ? "Detected" : "None",
    }
  };
};
