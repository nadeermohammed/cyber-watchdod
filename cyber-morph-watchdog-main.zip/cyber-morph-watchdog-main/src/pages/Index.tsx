
import NavBar from "@/components/NavBar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import FaceMorphingDemo from "@/components/FaceMorphingDemo";
import PhishingDetector from "@/components/PhishingDetector";
import LiveMetrics from "@/components/LiveMetrics";
import Footer from "@/components/Footer";
import { Toaster } from "@/components/ui/toaster";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <NavBar />
      <main className="flex-grow">
        <Hero />
        <Features />
        <FaceMorphingDemo />
        <PhishingDetector />
        <LiveMetrics />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default Index;
