
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { ArrowLeft } from "lucide-react";
import NavBar from "@/components/NavBar";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <NavBar />
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="text-center max-w-md glass-card rounded-xl p-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-cybergreen-500/10 mb-6">
            <span className="text-4xl font-bold text-cybergreen-400 text-glow">404</span>
          </div>
          <h1 className="text-2xl font-bold mb-4">Page Not Found</h1>
          <p className="text-foreground/70 mb-8">
            The page you are looking for might have been removed, had its name changed, 
            or is temporarily unavailable.
          </p>
          <a 
            href="/" 
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md font-medium bg-cybergreen-500 text-white hover:bg-cybergreen-400 transition-colors shadow-lg shadow-cybergreen-500/20"
          >
            <ArrowLeft size={16} />
            Return to Home
          </a>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
