
import { ArrowRight } from "lucide-react";

const Hero = () => {
  return (
    <div className="relative overflow-hidden">
      <div className="absolute inset-0 cybergrid"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            <span className="block text-foreground">AI-Powered</span>
            <span className="block text-cybergreen-400 text-glow">
              Cybersecurity Shield
            </span>
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 mb-8 max-w-2xl">
            Advanced protection against deepfakes and phishing attacks with
            cutting-edge AI detection technology. Secure your digital identity today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-6 py-3 rounded-md font-medium bg-cybergreen-500 text-white hover:bg-cybergreen-400 transition-colors shadow-lg shadow-cybergreen-500/20 flex items-center justify-center gap-2">
              Try It Now <ArrowRight size={16} />
            </button>
            <button className="px-6 py-3 rounded-md font-medium bg-secondary text-foreground hover:bg-secondary/80 transition-colors flex items-center justify-center">
              Learn More
            </button>
          </div>
        </div>
      </div>

      <div className="absolute right-0 bottom-0 transform translate-x-1/4 translate-y-1/4 opacity-20 pointer-events-none">
        <div className="w-96 h-96 rounded-full bg-gradient-to-r from-cybergreen-500/40 to-cybergreen-700/40 blur-3xl"></div>
      </div>
    </div>
  );
};

export default Hero;
