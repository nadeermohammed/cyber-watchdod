
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: string;
  isPositive?: boolean;
  className?: string;
}

const StatCard = ({ title, value, icon: Icon, change, isPositive, className }: StatCardProps) => {
  return (
    <div className={cn(
      "glass-card rounded-lg p-6",
      className
    )}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-foreground/60 text-sm">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
          {change && (
            <div className="flex items-center mt-2">
              <span 
                className={cn(
                  "text-xs font-medium",
                  isPositive ? "text-green-400" : "text-red-400"
                )}
              >
                {change}
              </span>
            </div>
          )}
        </div>
        <div className="w-10 h-10 rounded-lg bg-cybergreen-500/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-cybergreen-400" />
        </div>
      </div>
    </div>
  );
};

export default StatCard;
