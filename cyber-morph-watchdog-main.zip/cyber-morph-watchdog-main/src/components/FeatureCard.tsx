
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  className?: string;
}

const FeatureCard = ({ title, description, icon: Icon, className }: FeatureCardProps) => {
  return (
    <div className={cn(
      "glass-card rounded-lg p-6 transition-all duration-300 hover:shadow-lg hover:shadow-cybergreen-500/10 group",
      className
    )}>
      <div className="mb-4 w-12 h-12 rounded-lg bg-cybergreen-500/10 flex items-center justify-center group-hover:bg-cybergreen-500/20 transition-all duration-300">
        <Icon className="w-6 h-6 text-cybergreen-400" />
      </div>
      <h3 className="text-xl font-semibold mb-2 group-hover:text-cybergreen-400 transition-colors">{title}</h3>
      <p className="text-foreground/70">{description}</p>
    </div>
  );
};

export default FeatureCard;
