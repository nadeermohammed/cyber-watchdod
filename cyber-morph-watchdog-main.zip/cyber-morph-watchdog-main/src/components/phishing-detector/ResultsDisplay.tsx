
import { AlertTriangle, CheckCircle, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { DangerLevel, PhishingResult } from "@/utils/phishingDetection";
import SecurityScoreCard from "./SecurityScoreCard";
import AnalyzedUrlDisplay from "./AnalyzedUrlDisplay";
import DomainInfoCard from "./DomainInfoCard";

interface ResultsDisplayProps {
  result: PhishingResult | null;
}

const ResultsDisplay = ({ result }: ResultsDisplayProps) => {
  if (!result) return null;

  return (
    <div className="space-y-6 animate-fade">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold">Security Analysis Results</h3>
        <DangerBadge dangerLevel={result.dangerLevel} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SecurityScoreCard score={result.score} dangerLevel={result.dangerLevel} />
        <AnalyzedUrlDisplay url={result.url} isHttps={result.details.https} />
      </div>

      <DomainInfoCard result={result} />
    </div>
  );
};

interface DangerBadgeProps {
  dangerLevel: DangerLevel;
}

const DangerBadge = ({ dangerLevel }: DangerBadgeProps) => {
  const getDangerColor = (level: DangerLevel) => {
    switch (level) {
      case "Safe": return "text-green-400 bg-green-400/10";
      case "Medium": return "text-yellow-400 bg-yellow-400/10";
      case "High": return "text-red-400 bg-red-400/10";
      default: return "text-foreground bg-background";
    }
  };

  const getDangerIcon = (level: DangerLevel) => {
    switch (level) {
      case "Safe": return <CheckCircle className="w-5 h-5" />;
      case "Medium": return <Info className="w-5 h-5" />;
      case "High": return <AlertTriangle className="w-5 h-5" />;
      default: return null;
    }
  };

  return (
    <div className={cn(
      "px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1.5",
      getDangerColor(dangerLevel)
    )}>
      {getDangerIcon(dangerLevel)}
      <span>{dangerLevel} {dangerLevel !== "Safe" && "Risk"}</span>
    </div>
  );
};

export default ResultsDisplay;
