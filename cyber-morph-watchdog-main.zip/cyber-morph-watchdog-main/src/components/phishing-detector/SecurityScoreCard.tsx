
import { cn } from "@/lib/utils";
import { DangerLevel } from "@/utils/phishingDetection";

interface SecurityScoreCardProps {
  score: number;
  dangerLevel: DangerLevel;
}

const SecurityScoreCard = ({ score, dangerLevel }: SecurityScoreCardProps) => {
  return (
    <div className="rounded-lg bg-secondary/50 p-4 border border-border">
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-medium text-foreground/80">Security Score</h4>
      </div>
      <div className="flex items-end gap-2">
        <span className="text-3xl font-bold text-foreground">{score}/100</span>
      </div>
      <div className="mt-3 h-2 bg-secondary rounded-full overflow-hidden">
        <div 
          className={cn(
            "h-full",
            dangerLevel === "Safe" ? "bg-green-400" : 
            dangerLevel === "Medium" ? "bg-yellow-400" : "bg-red-400"
          )} 
          style={{ width: `${score}%` }}
        ></div>
      </div>
      <div className="flex justify-between mt-2 text-xs text-foreground/60">
        <span>High Risk</span>
        <span>Medium Risk</span>
        <span>Safe</span>
      </div>
    </div>
  );
};

export default SecurityScoreCard;
