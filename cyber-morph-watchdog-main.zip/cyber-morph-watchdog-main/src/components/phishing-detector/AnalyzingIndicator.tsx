
import { Shield } from "lucide-react";

interface AnalyzingIndicatorProps {
  isAnalyzing: boolean;
}

const AnalyzingIndicator = ({ isAnalyzing }: AnalyzingIndicatorProps) => {
  if (!isAnalyzing) return null;

  return (
    <div className="text-center py-12">
      <div className="inline-block rounded-full p-4 bg-cybergreen-500/10 animate-pulse mb-4">
        <Shield className="h-10 w-10 text-cybergreen-400" />
      </div>
      <p className="text-lg">Analyzing URL security and reputation...</p>
      <div className="mt-4 max-w-md mx-auto h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className="h-full bg-cybergreen-500 animate-pulse" style={{ width: "80%" }}></div>
      </div>
    </div>
  );
};

export default AnalyzingIndicator;
