
import { Globe, Search } from "lucide-react";
import { cn } from "@/lib/utils";

interface URLFormProps {
  url: string;
  setUrl: (url: string) => void;
  handleSubmit: (e: React.FormEvent) => void;
  isAnalyzing: boolean;
}

const URLForm = ({ url, setUrl, handleSubmit, isAnalyzing }: URLFormProps) => {
  return (
    <form onSubmit={handleSubmit} className="mb-8">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Globe className="h-5 w-5 text-foreground/50" />
          </div>
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter a URL (e.g., https://example.com)"
            className="block w-full pl-10 pr-4 py-3 rounded-md bg-secondary border border-border focus:border-cybergreen-400 focus:ring-1 focus:ring-cybergreen-400 text-foreground focus:outline-none"
            disabled={isAnalyzing}
          />
        </div>
        <button
          type="submit"
          disabled={isAnalyzing || !url}
          className={cn(
            "px-6 py-3 rounded-md font-medium bg-cybergreen-500 text-white hover:bg-cybergreen-400 transition-colors shadow-lg shadow-cybergreen-500/20 flex items-center justify-center gap-2",
            (isAnalyzing || !url) && "opacity-70 cursor-not-allowed"
          )}
        >
          {isAnalyzing ? "Analyzing..." : "Analyze URL"}
          {!isAnalyzing && <Search size={18} />}
        </button>
      </div>
    </form>
  );
};

export default URLForm;
