
import { AlertTriangle, Lock } from "lucide-react";

interface AnalyzedUrlDisplayProps {
  url: string;
  isHttps: boolean;
}

const AnalyzedUrlDisplay = ({ url, isHttps }: AnalyzedUrlDisplayProps) => {
  return (
    <div className="rounded-lg bg-secondary/50 p-4 border border-border">
      <h4 className="font-medium text-foreground/80 mb-3">Analyzed URL</h4>
      <div className="flex items-center gap-2 bg-background/50 p-2 rounded">
        <p className="text-sm break-all flex-1">{url}</p>
        {isHttps ? (
          <Lock className="h-4 w-4 text-green-400 flex-shrink-0" aria-label="HTTPS Secure" />
        ) : (
          <AlertTriangle className="h-4 w-4 text-red-400 flex-shrink-0" aria-label="Not HTTPS Secured" />
        )}
      </div>
    </div>
  );
};

export default AnalyzedUrlDisplay;
