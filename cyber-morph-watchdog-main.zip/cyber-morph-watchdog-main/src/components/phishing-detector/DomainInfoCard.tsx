
import { AlertTriangle, Calendar, CheckCircle, Globe, Info, Shield } from "lucide-react";
import { DangerLevel, PhishingResult } from "@/utils/phishingDetection";

interface DomainInfoCardProps {
  result: PhishingResult;
}

const DomainInfoCard = ({ result }: DomainInfoCardProps) => {
  return (
    <div className="rounded-lg bg-secondary/50 p-4 border border-border">
      <h4 className="font-medium text-foreground/80 mb-3">Domain Information</h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-cybergreen-400" />
          <div>
            <p className="text-xs text-foreground/60">Domain Age</p>
            <p className="text-sm">{result.details.domainAge}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-cybergreen-400" />
          <div>
            <p className="text-xs text-foreground/60">Server Location</p>
            <p className="text-sm">{result.details.location}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Info className="w-5 h-5 text-cybergreen-400" />
          <div>
            <p className="text-xs text-foreground/60">Domain Registrar</p>
            <p className="text-sm">{result.details.registrar}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-cybergreen-400" />
          <div>
            <p className="text-xs text-foreground/60">SSL Certificate</p>
            <p className="text-sm">{result.details.ssl}</p>
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-3 border-t border-border">
        <div className="flex items-center gap-2">
          <div className={result.details.blacklisted ? "text-red-400" : "text-green-400"}>
            {result.details.blacklisted ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
          </div>
          <p className="text-sm">
            {result.details.blacklisted 
              ? "Domain appears on security blacklists" 
              : "Domain is not blacklisted in security databases"}
          </p>
        </div>
        {result.details.suspiciousPatterns !== "None" && (
          <div className="flex items-center gap-2 mt-2">
            <div className="text-yellow-400">
              <Info className="w-5 h-5" />
            </div>
            <p className="text-sm">Suspicious patterns detected in URL</p>
          </div>
        )}
      </div>
      
      <RiskBanner dangerLevel={result.dangerLevel} />
    </div>
  );
};

interface RiskBannerProps {
  dangerLevel: DangerLevel;
}

const RiskBanner = ({ dangerLevel }: RiskBannerProps) => {
  if (dangerLevel === "Safe") {
    return (
      <div className="mt-4 pt-3 border-t border-border">
        <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-md flex items-center gap-3">
          <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0" />
          <div>
            <p className="font-medium text-green-400">Safe to Visit</p>
            <p className="text-sm text-foreground/70">Our analysis indicates this URL is trustworthy</p>
          </div>
        </div>
      </div>
    );
  }
  
  if (dangerLevel === "Medium") {
    return (
      <div className="mt-4 pt-3 border-t border-border">
        <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-md flex items-center gap-3">
          <Info className="w-6 h-6 text-yellow-400 flex-shrink-0" />
          <div>
            <p className="font-medium text-yellow-400">Proceed with Caution</p>
            <p className="text-sm text-foreground/70">This URL has some suspicious characteristics</p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="mt-4 pt-3 border-t border-border">
      <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-md flex items-center gap-3">
        <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0" />
        <div>
          <p className="font-medium text-red-400">Warning: Potentially Unsafe</p>
          <p className="text-sm text-foreground/70">This URL shows strong indicators of being malicious</p>
        </div>
      </div>
    </div>
  );
};

export default DomainInfoCard;
