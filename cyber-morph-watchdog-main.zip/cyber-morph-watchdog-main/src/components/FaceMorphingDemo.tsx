
import { useState, useRef } from "react";
import { Upload, Scan, AlertTriangle, CheckCircle, Video, Camera } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/components/ui/use-toast";

const FaceMorphingDemo = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [media, setMedia] = useState<{ type: "image" | "video", src: string } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<null | { isMorphed: boolean; confidence: number }>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      handleMediaFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      handleMediaFile(file);
    }
  };

  const handleMediaFile = (file: File) => {
    const reader = new FileReader();
    
    if (file.type.startsWith('image/')) {
      reader.onload = (readerEvent) => {
        if (readerEvent.target) {
          setMedia({
            type: "image",
            src: readerEvent.target.result as string
          });
          setResult(null);
        }
      };
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('video/')) {
      reader.onload = (readerEvent) => {
        if (readerEvent.target) {
          setMedia({
            type: "video",
            src: readerEvent.target.result as string
          });
          setResult(null);
        }
      };
      reader.readAsDataURL(file);
    } else {
      toast({
        title: "Unsupported file format",
        description: "Please upload an image or video file.",
        variant: "destructive"
      });
    }
  };

  const startVideoCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      mediaStreamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      
      setMedia({
        type: "video",
        src: ""
      });
      
      toast({
        title: "Camera activated",
        description: "You can now record a video for analysis.",
      });
    } catch (err) {
      console.error("Error accessing camera:", err);
      toast({
        title: "Camera access denied",
        description: "Please allow camera access and try again.",
        variant: "destructive"
      });
    }
  };

  const startRecording = () => {
    if (!mediaStreamRef.current) return;
    
    const mediaRecorder = new MediaRecorder(mediaStreamRef.current);
    mediaRecorderRef.current = mediaRecorder;
    
    const chunks: BlobPart[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        chunks.push(e.data);
      }
    };
    
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      setRecordedBlob(blob);
      const url = URL.createObjectURL(blob);
      setMedia({
        type: "video",
        src: url
      });
    };
    
    mediaRecorder.start();
    setIsRecording(true);
    
    toast({
      title: "Recording started",
      description: "Recording video for face morphing analysis.",
    });
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      // Stop all tracks of the stream
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
      
      toast({
        title: "Recording completed",
        description: "You can now analyze the recorded video.",
      });
    }
  };

  const analyzeMedia = () => {
    if (!media) return;
    
    setIsAnalyzing(true);
    setResult(null);
    
    // Simulate analysis delay
    setTimeout(() => {
      // Mock result - in a real app this would come from an API
      const mockResult = {
        isMorphed: Math.random() > 0.5,
        confidence: Math.round(Math.random() * 40 + 60) // 60-100%
      };
      
      setResult(mockResult);
      setIsAnalyzing(false);
      
      // Show toast with result
      if (mockResult.isMorphed) {
        toast({
          title: "⚠️ Potential morphing detected",
          description: `Our AI detected potential manipulation with ${mockResult.confidence}% confidence.`,
          variant: "destructive"
        });
      } else {
        toast({
          title: "✅ No manipulation detected",
          description: `Media appears to be authentic (${mockResult.confidence}% confidence).`,
        });
      }
    }, 2000);
  };

  const resetDemo = () => {
    setMedia(null);
    setResult(null);
    setRecordedBlob(null);
    
    // Ensure any active media streams are stopped
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  return (
    <section id="face-detection" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            <span className="text-cybergreen-400 text-glow">Face Morphing</span> Detection
          </h2>
          <p className="text-foreground/70 max-w-2xl mx-auto">
            Our advanced AI can detect if facial media has been digitally manipulated or deepfaked.
            Upload an image or video to see it in action.
          </p>
        </div>

        <div className="max-w-3xl mx-auto glass-card rounded-xl p-8">
          {!media ? (
            <div className="space-y-6">
              <div
                className={cn(
                  "border-2 border-dashed rounded-lg p-12 text-center transition-all cursor-pointer",
                  isDragging ? "border-cybergreen-400 bg-cybergreen-500/5" : "border-border"
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById("file-upload")?.click()}
              >
                <Upload className="mx-auto h-12 w-12 text-foreground/50 mb-4" />
                <p className="text-lg mb-2">Drag and drop media here, or click to browse</p>
                <p className="text-sm text-foreground/60">
                  Supported formats: Images (JPG, PNG), Videos (MP4, WEBM)
                </p>
                <input
                  id="file-upload"
                  type="file"
                  className="hidden"
                  accept="image/*,video/*"
                  onChange={handleFileChange}
                />
              </div>
              
              <div className="text-center">
                <p className="text-foreground/70 mb-4">Or use your camera:</p>
                <button
                  onClick={startVideoCapture}
                  className="py-2 px-4 rounded-md bg-cybergreen-500 text-white hover:bg-cybergreen-400 transition-colors flex items-center justify-center gap-2 mx-auto"
                >
                  <Video size={18} /> Start Camera
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="relative">
                {media.type === "image" ? (
                  <img
                    src={media.src}
                    alt="Uploaded image"
                    className="rounded-lg w-full max-h-[400px] object-contain mx-auto"
                  />
                ) : (
                  <div className="relative">
                    <video
                      ref={videoRef}
                      src={media.src || undefined}
                      className="rounded-lg w-full max-h-[400px] object-contain mx-auto"
                      controls={!!media.src}
                      autoPlay={!media.src}
                      muted
                      playsInline
                    />
                    
                    {!media.src && !isRecording && (
                      <button
                        onClick={startRecording}
                        className="mt-4 py-2 px-4 rounded-md bg-red-500 text-white hover:bg-red-400 transition-colors flex items-center justify-center gap-2 mx-auto"
                      >
                        <Camera size={18} /> Start Recording
                      </button>
                    )}
                    
                    {isRecording && (
                      <div className="mt-4 flex items-center justify-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
                        <span className="text-red-500">Recording...</span>
                        <button
                          onClick={stopRecording}
                          className="ml-4 py-2 px-4 rounded-md bg-gray-500 text-white hover:bg-gray-400 transition-colors"
                        >
                          Stop Recording
                        </button>
                      </div>
                    )}
                  </div>
                )}
                
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-background/50 backdrop-blur-sm flex items-center justify-center">
                    <div className="flex flex-col items-center">
                      <Scan className="h-12 w-12 text-cybergreen-400 animate-pulse" />
                      <p className="mt-4 text-cybergreen-400">Analyzing {media.type}...</p>
                    </div>
                  </div>
                )}
              </div>

              {result && (
                <div className={cn(
                  "rounded-lg p-4 flex items-center gap-3",
                  result.isMorphed ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"
                )}>
                  {result.isMorphed ? (
                    <AlertTriangle className="h-6 w-6 flex-shrink-0" />
                  ) : (
                    <CheckCircle className="h-6 w-6 flex-shrink-0" />
                  )}
                  <div>
                    <p className="font-medium">
                      {result.isMorphed ? "Potential face morphing detected!" : "No manipulation detected"}
                    </p>
                    <p className="text-sm opacity-90">
                      Confidence: {result.confidence}%
                    </p>
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                {!result && !isAnalyzing && media.src && (
                  <button
                    onClick={analyzeMedia}
                    className="flex-1 py-2 rounded-md bg-cybergreen-500 text-white hover:bg-cybergreen-400 transition-colors flex items-center justify-center gap-2"
                  >
                    <Scan size={18} /> Analyze {media.type === "image" ? "Image" : "Video"}
                  </button>
                )}
                <button
                  onClick={resetDemo}
                  className="flex-1 py-2 rounded-md bg-secondary text-foreground hover:bg-secondary/80 transition-colors"
                >
                  Upload Another {media.type === "image" ? "Image" : "Media"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default FaceMorphingDemo;
