
import { Shield, Image, Link2, PieChart } from "lucide-react";
import FeatureCard from "./FeatureCard";

const Features = () => {
  const features = [
    {
      icon: Image,
      title: "Face Morphing Detection",
      description:
        "AI-powered analysis identifies digitally manipulated facial images with precise confidence scoring.",
    },
    {
      icon: Link2,
      title: "Phishing URL Analysis",
      description:
        "Advanced algorithms detect malicious URLs by examining domain age, reputation, and content patterns.",
    },
    {
      icon: Shield,
      title: "Real-time Protection",
      description:
        "Continuous monitoring system that alerts you instantly when threats are detected.",
    },
    {
      icon: PieChart,
      title: "Risk Assessment Dashboard",
      description:
        "Comprehensive visual analytics of security threats and system performance.",
    },
  ];

  return (
    <section id="features" className="py-20 relative">
      <div className="absolute inset-0 cybergrid opacity-50"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">
            Advanced <span className="text-cybergreen-400 text-glow">Security</span> Features
          </h2>
          <p className="text-foreground/70 max-w-2xl mx-auto">
            Our cutting-edge cybersecurity platform offers comprehensive protection against the most sophisticated digital threats.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
