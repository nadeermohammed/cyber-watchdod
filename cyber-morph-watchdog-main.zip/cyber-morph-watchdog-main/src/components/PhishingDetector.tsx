
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { PhishingResult, analyzeDomain } from "@/utils/phishingDetection";
import URLForm from "./phishing-detector/URLForm";
import AnalyzingIndicator from "./phishing-detector/AnalyzingIndicator";
import ResultsDisplay from "./phishing-detector/ResultsDisplay";

const PhishingDetector = () => {
  const [url, setUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<PhishingResult | null>(null);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    setIsAnalyzing(true);
    setResult(null);
    
    // Simulate API call delay
    setTimeout(() => {
      // Get results from our phishing detection utility
      const result = analyzeDomain(url);
      
      setResult(result);
      setIsAnalyzing(false);
      
      // Show toast notification based on danger level
      if (result.dangerLevel === "Safe") {
        toast({
          title: "URL Analysis Complete",
          description: "This URL appears to be safe to visit",
          variant: "default",
        });
      } else if (result.dangerLevel === "Medium") {
        toast({
          title: "Caution Required",
          description: "This URL has some suspicious characteristics",
          variant: "default",
          className: "bg-yellow-500/10 border-yellow-500 text-foreground",
        });
      } else {
        toast({
          title: "High Risk Detected!",
          description: "This URL shows strong indicators of being malicious",
          variant: "destructive",
        });
      }
    }, 2000);
  };

  return (
    <section id="phishing-detection" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            <span className="text-cybergreen-400 text-glow">Phishing URL</span> Detection
          </h2>
          <p className="text-foreground/70 max-w-2xl mx-auto">
            Our advanced security system analyzes URLs to identify potential phishing threats with high accuracy.
            Enter a URL below to check if it's safe to visit.
          </p>
        </div>

        <div className="max-w-3xl mx-auto glass-card rounded-xl p-8 border border-cybergreen-500/20 shadow-lg shadow-cybergreen-500/10">
          <URLForm 
            url={url}
            setUrl={setUrl}
            handleSubmit={handleSubmit}
            isAnalyzing={isAnalyzing}
          />

          <AnalyzingIndicator isAnalyzing={isAnalyzing} />
          <ResultsDisplay result={result} />
        </div>
      </div>
    </section>
  );
};

export default PhishingDetector;
