
import { BarChart, Shield, Users, Link } from "lucide-react";
import StatCard from "./StatCard";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const LiveMetrics = () => {
  // Mock data for the chart
  const data = [
    { name: "Jan", threats: 65 },
    { name: "Feb", threats: 59 },
    { name: "Mar", threats: 80 },
    { name: "Apr", threats: 81 },
    { name: "May", threats: 56 },
    { name: "Jun", threats: 55 },
    { name: "Jul", threats: 40 },
    { name: "Aug", threats: 70 },
    { name: "Sep", threats: 90 },
    { name: "Oct", threats: 75 },
    { name: "Nov", threats: 60 },
    { name: "Dec", threats: 45 },
  ];

  return (
    <section id="analytics" className="py-20 relative">
      <div className="absolute inset-0 cybergrid opacity-50"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">
            <span className="text-cybergreen-400 text-glow">Live</span> Security Metrics
          </h2>
          <p className="text-foreground/70 max-w-2xl mx-auto">
            Real-time dashboard showing current threat levels and system performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Threats Blocked"
            value="15,492"
            icon={Shield}
            change="+8.2% this month"
            isPositive={true}
          />
          <StatCard
            title="Active Users"
            value="2,849"
            icon={Users}
            change="+12.5% this month"
            isPositive={true}
          />
          <StatCard
            title="Phishing URLs"
            value="843"
            icon={Link}
            change="-4.3% this month"
            isPositive={true}
          />
          <StatCard
            title="Security Score"
            value="94.5%"
            icon={BarChart}
            change="+2.1% this month"
            isPositive={true}
          />
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">Threat Detection Trends</h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-cybergreen-400"></div>
                <span className="text-sm text-foreground/60">Threats Blocked</span>
              </div>
            </div>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={data}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0aba86" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#0aba86" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="name" 
                  tick={{ fill: '#9CA3AF' }}
                  axisLine={{ stroke: '#374151' }}
                />
                <YAxis 
                  tick={{ fill: '#9CA3AF' }}
                  axisLine={{ stroke: '#374151' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(4, 24, 16, 0.9)',
                    borderColor: '#0aba86',
                    borderRadius: '4px',
                    color: '#F3F4F6',
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="threats" 
                  stroke="#0aba86" 
                  fillOpacity={1} 
                  fill="url(#colorThreats)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveMetrics;
