import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { ImageUploader } from './components/ImageUploader';
import { DetectionResults } from './components/DetectionResults';
import { Dashboard } from './components/Dashboard';
import { APIIntegration } from './components/APIIntegration';
import { Settings } from './components/Settings';
import { 
  Upload, 
  BarChart3, 
  Code2, 
  Settings2, 
  Shield, 
  AlertTriangle,
  FileImage,
  FileVideo
} from 'lucide-react';

// Define the tabs for the application
const tabs = [
  { id: 'upload', name: 'Upload & Scan', icon: <Upload size={20} /> },
  { id: 'dashboard', name: 'Dashboard', icon: <BarChart3 size={20} /> },
  { id: 'api', name: 'API Integration', icon: <Code2 size={20} /> },
  { id: 'settings', name: 'Settings', icon: <Settings2 size={20} /> },
];

// Define the scan result type
export type ScanResult = {
  id: string;
  filename: string;
  timestamp: string;
  threatScore: number;
  manipulationProbability: number;
  manipulationTypes: {
    faceSwap: number;
    morphing: number;
    synthesis: number;
    attributes: number;
  };
  regions: {
    x: number;
    y: number;
    width: number;
    height: number;
    confidence: number;
    type: string;
  }[];
  originalImage: string;
  processedImage: string;
};

// Define the scan history type
export type ScanHistory = {
  totalScans: number;
  detectedThreats: number;
  scansByDate: {
    date: string;
    scans: number;
    threats: number;
  }[];
  recentScans: ScanResult[];
};

function App() {
  const [activeTab, setActiveTab] = useState('upload');
  const [currentScan, setCurrentScan] = useState<ScanResult | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanHistory>({
    totalScans: 156,
    detectedThreats: 23,
    scansByDate: [
      { date: '2025-01-01', scans: 12, threats: 2 },
      { date: '2025-01-02', scans: 8, threats: 1 },
      { date: '2025-01-03', scans: 15, threats: 3 },
      { date: '2025-01-04', scans: 10, threats: 0 },
      { date: '2025-01-05', scans: 20, threats: 4 },
      { date: '2025-01-06', scans: 18, threats: 2 },
      { date: '2025-01-07', scans: 25, threats: 5 },
    ],
    recentScans: [
      {
        id: 'scan-001',
        filename: 'employee_id_verification.jpg',
        timestamp: '2025-01-07T14:32:45Z',
        threatScore: 87,
        manipulationProbability: 0.92,
        manipulationTypes: {
          faceSwap: 0.15,
          morphing: 0.85,
          synthesis: 0.32,
          attributes: 0.12,
        },
        regions: [
          {
            x: 120,
            y: 80,
            width: 100,
            height: 100,
            confidence: 0.92,
            type: 'morphing',
          },
        ],
        originalImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        processedImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      },
      {
        id: 'scan-002',
        filename: 'customer_verification.jpg',
        timestamp: '2025-01-07T10:15:22Z',
        threatScore: 92,
        manipulationProbability: 0.95,
        manipulationTypes: {
          faceSwap: 0.88,
          morphing: 0.45,
          synthesis: 0.12,
          attributes: 0.08,
        },
        regions: [
          {
            x: 150,
            y: 100,
            width: 120,
            height: 120,
            confidence: 0.95,
            type: 'faceSwap',
          },
        ],
        originalImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        processedImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      },
      {
        id: 'scan-003',
        filename: 'passport_verification.jpg',
        timestamp: '2025-01-06T16:45:12Z',
        threatScore: 75,
        manipulationProbability: 0.78,
        manipulationTypes: {
          faceSwap: 0.25,
          morphing: 0.75,
          synthesis: 0.45,
          attributes: 0.30,
        },
        regions: [
          {
            x: 130,
            y: 90,
            width: 110,
            height: 110,
            confidence: 0.78,
            type: 'morphing',
          },
        ],
        originalImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        processedImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      },
    ],
  });

  // Mock function to simulate AI scan
  const handleScan = (file: File, type: 'image' | 'video') => {
    // In a real application, this would send the file to a backend API
    // For this prototype, we'll simulate a response after a delay
    
    // Create a new scan result
    const newScan: ScanResult = {
      id: `scan-${Math.floor(Math.random() * 1000)}`,
      filename: file.name,
      timestamp: new Date().toISOString(),
      threatScore: Math.floor(Math.random() * 100),
      manipulationProbability: Math.random(),
      manipulationTypes: {
        faceSwap: Math.random(),
        morphing: Math.random(),
        synthesis: Math.random(),
        attributes: Math.random(),
      },
      regions: [
        {
          x: 120 + Math.floor(Math.random() * 50),
          y: 80 + Math.floor(Math.random() * 50),
          width: 100,
          height: 100,
          confidence: Math.random(),
          type: Math.random() > 0.5 ? 'morphing' : 'faceSwap',
        },
      ],
      originalImage: URL.createObjectURL(file),
      processedImage: URL.createObjectURL(file), // In a real app, this would be a processed image
    };

    // Update the current scan
    setCurrentScan(newScan);

    // Update scan history
    const today = new Date().toISOString().split('T')[0];
    const updatedHistory = { ...scanHistory };
    
    // Update total scans
    updatedHistory.totalScans += 1;
    
    // Update detected threats if threat score is high
    if (newScan.threatScore > 70) {
      updatedHistory.detectedThreats += 1;
    }
    
    // Update scans by date
    const todayIndex = updatedHistory.scansByDate.findIndex(item => item.date === today);
    if (todayIndex >= 0) {
      updatedHistory.scansByDate[todayIndex].scans += 1;
      if (newScan.threatScore > 70) {
        updatedHistory.scansByDate[todayIndex].threats += 1;
      }
    } else {
      updatedHistory.scansByDate.push({
        date: today,
        scans: 1,
        threats: newScan.threatScore > 70 ? 1 : 0,
      });
    }
    
    // Add to recent scans
    updatedHistory.recentScans.unshift(newScan);
    if (updatedHistory.recentScans.length > 10) {
      updatedHistory.recentScans.pop();
    }
    
    setScanHistory(updatedHistory);
  };

  // Function to render the active tab content
  const renderTabContent = () => {
    switch (activeTab) {
      case 'upload':
        return currentScan ? (
          <DetectionResults 
            scanResult={currentScan} 
            onReset={() => setCurrentScan(null)} 
          />
        ) : (
          <ImageUploader onScan={handleScan} />
        );
      case 'dashboard':
        return <Dashboard scanHistory={scanHistory} />;
      case 'api':
        return <APIIntegration />;
      case 'settings':
        return <Settings />;
      default:
        return <ImageUploader onScan={handleScan} />;
    }
  };

  return (
    <Layout>
      <div className="flex flex-col h-full">
        <header className="bg-gradient-to-r from-purple-700 to-indigo-800 p-6 text-white">
          <div className="flex items-center">
            <Shield size={32} className="mr-3" />
            <h1 className="text-3xl font-bold">AI Face Morphing Detection</h1>
          </div>
          <p className="mt-2 text-purple-100">Detect and prevent face morphing attacks for enhanced cybersecurity</p>
        </header>

        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          {/* Sidebar Navigation */}
          <nav className="bg-gray-800 text-white w-full md:w-64 flex-shrink-0">
            <div className="p-4">
              <div className="mb-6 p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center">
                  <AlertTriangle size={18} className="text-yellow-400 mr-2" />
                  <span className="text-sm font-medium">Threat Status</span>
                </div>
                <div className="mt-2 flex justify-between">
                  <div>
                    <div className="text-xs text-gray-400">Total Scans</div>
                    <div className="text-lg font-semibold">{scanHistory.totalScans}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Threats</div>
                    <div className="text-lg font-semibold text-red-400">{scanHistory.detectedThreats}</div>
                  </div>
                </div>
              </div>
              
              <ul>
                {tabs.map((tab) => (
                  <li key={tab.id} className="mb-2">
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center w-full p-3 rounded-lg transition-colors ${
                        activeTab === tab.id
                          ? 'bg-purple-700 text-white'
                          : 'text-gray-300 hover:bg-gray-700'
                      }`}
                    >
                      <span className="mr-3">{tab.icon}</span>
                      {tab.name}
                    </button>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8 pt-6 border-t border-gray-700">
                <h3 className="text-sm font-medium text-gray-400 mb-3">Quick Actions</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button className="flex flex-col items-center justify-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors">
                    <FileImage size={20} className="mb-1" />
                    <span className="text-xs">Scan Image</span>
                  </button>
                  <button className="flex flex-col items-center justify-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors">
                    <FileVideo size={20} className="mb-1" />
                    <span className="text-xs">Scan Video</span>
                  </button>
                </div>
              </div>
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-1 overflow-auto bg-gray-100 p-6">
            {renderTabContent()}
          </main>
        </div>
      </div>
    </Layout>
  );
}

export default App;