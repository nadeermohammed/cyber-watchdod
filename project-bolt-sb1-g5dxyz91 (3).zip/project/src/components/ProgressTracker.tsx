import React, { useState } from 'react';
import { ClientProfile } from '../App';
import { LineChart, BarChart, Calendar, Camera } from 'lucide-react';

interface ProgressTrackerProps {
  clientProfile: ClientProfile | null;
}

interface ProgressEntry {
  date: string;
  weight: number;
  bodyFat?: number;
  notes: string;
  measurements?: {
    chest?: number;
    waist?: number;
    hips?: number;
    arms?: number;
    thighs?: number;
  };
}

export const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  clientProfile,
}) => {
  const [progressEntries, setProgressEntries] = useState<ProgressEntry[]>([
    {
      date: '2025-01-01',
      weight: 75,
      bodyFat: 22,
      notes: 'Starting point',
      measurements: {
        chest: 95,
        waist: 85,
        hips: 100,
        arms: 33,
        thighs: 55,
      },
    },
    {
      date: '2025-01-08',
      weight: 74.2,
      bodyFat: 21.5,
      notes: 'Feeling good, energy levels improving',
      measurements: {
        chest: 94.5,
        waist: 84,
        hips: 99.5,
        arms: 33.2,
        thighs: 54.8,
      },
    },
    {
      date: '2025-01-15',
      weight: 73.5,
      bodyFat: 21,
      notes: 'Strength increasing, sleep improving',
      measurements: {
        chest: 94,
        waist: 83,
        hips: 99,
        arms: 33.5,
        thighs: 54.5,
      },
    },
    {
      date: '2025-01-22',
      weight: 72.8,
      bodyFat: 20.5,
      notes: 'Noticing visual changes, clothes fitting better',
      measurements: {
        chest: 93.5,
        waist: 82,
        hips: 98.5,
        arms: 34,
        thighs: 54,
      },
    },
  ]);

  const [newEntry, setNewEntry] = useState<ProgressEntry>({
    date: new Date().toISOString().split('T')[0],
    weight: clientProfile?.weight || 0,
    bodyFat: undefined,
    notes: '',
    measurements: {
      chest: undefined,
      waist: undefined,
      hips: undefined,
      arms: undefined,
      thighs: undefined,
    },
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setNewEntry({
      ...newEntry,
      [name]: value,
    });
  };

  const handleMeasurementChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { name, value } = e.target;
    setNewEntry({
      ...newEntry,
      measurements: {
        ...newEntry.measurements,
        [name]: value ? parseFloat(value) : undefined,
      },
    });
  };

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    setProgressEntries([...progressEntries, { ...newEntry }]);
    setNewEntry({
      date: new Date().toISOString().split('T')[0],
      weight: clientProfile?.weight || 0,
      bodyFat: undefined,
      notes: '',
      measurements: {
        chest: undefined,
        waist: undefined,
        hips: undefined,
        arms: undefined,
        thighs: undefined,
      },
    });
  };

  if (!clientProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Progress Tracker</h2>
          <p className="text-gray-600 mb-4">
            Please complete the client profile first to track progress.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Progress Tracker</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Progress Charts */}
        <div>
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <div className="flex items-center mb-4">
              <LineChart size={20} className="mr-2 text-blue-600" />
              <h3 className="text-lg font-medium">Weight Progress</h3>
            </div>
            <div className="h-64 bg-white p-4 rounded border border-gray-200 flex items-center justify-center">
              {/* Placeholder for actual chart */}
              <div className="w-full h-full relative">
                <div className="absolute bottom-0 left-0 right-0 h-px bg-gray-300"></div>
                <div className="absolute top-0 bottom-0 left-0 w-px bg-gray-300"></div>
                
                {progressEntries.map((entry, index) => {
                  const x = (index / (progressEntries.length - 1)) * 100;
                  const maxWeight = Math.max(...progressEntries.map(e => e.weight));
                  const minWeight = Math.min(...progressEntries.map(e => e.weight));
                  const range = maxWeight - minWeight;
                  const y = 100 - (((entry.weight - minWeight) / (range || 1)) * 80);
                  
                  return (
                    <div 
                      key={index}
                      className="absolute w-3 h-3 bg-blue-600 rounded-full transform -translate-x-1.5 -translate-y-1.5"
                      style={{ left: `${x}%`, top: `${y}%` }}
                    ></div>
                  );
                })}
                
                {progressEntries.map((entry, index) => {
                  if (index === 0) return null;
                  
                  const prevIndex = index - 1;
                  const prevX = (prevIndex / (progressEntries.length - 1)) * 100;
                  const x = (index / (progressEntries.length - 1)) * 100;
                  
                  const maxWeight = Math.max(...progressEntries.map(e => e.weight));
                  const minWeight = Math.min(...progressEntries.map(e => e.weight));
                  const range = maxWeight - minWeight;
                  
                  const prevY = 100 - (((progressEntries[prevIndex].weight - minWeight) / (range || 1)) * 80);
                  const y = 100 - (((entry.weight - minWeight) / (range || 1)) * 80);
                  
                  return (
                    <svg 
                      key={`line-${index}`}
                      className="absolute top-0 left-0 w-full h-full"
                      style={{ zIndex: -1 }}
                    >
                      <line 
                        x1={`${prevX}%`} 
                        y1={`${prevY}%`} 
                        x2={`${x}%`} 
                        y2={`${y}%`} 
                        stroke="#2563EB" 
                        strokeWidth="2" 
                      />
                    </svg>
                  );
                })}
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <BarChart size={20} className="mr-2 text-blue-600" />
              <h3 className="text-lg font-medium">Body Measurements</h3>
            </div>
            <div className="h-64 bg-white p-4 rounded border border-gray-200 flex items-center justify-center">
              {/* Placeholder for actual chart */}
              <div className="w-full grid grid-cols-5 gap-2 h-full">
                {progressEntries.length > 0 && progressEntries[0].measurements && Object.keys(progressEntries[0].measurements).map((key) => {
                  const latestEntry = progressEntries[progressEntries.length - 1];
                  const firstEntry = progressEntries[0];
                  
                  // Type assertion to access dynamic property
                  const latestValue = latestEntry.measurements?.[key as keyof typeof latestEntry.measurements];
                  const firstValue = firstEntry.measurements?.[key as keyof typeof firstEntry.measurements];
                  
                  if (latestValue === undefined || firstValue === undefined) return null;
                  
                  const percentChange = ((latestValue - firstValue) / firstValue) * 100;
                  const barHeight = Math.min(Math.abs(percentChange) * 10, 80);
                  
                  return (
                    <div key={key} className="flex flex-col items-center justify-end h-full">
                      <div className="text-xs text-gray-500 mb-1">
                        {percentChange > 0 ? '+' : ''}{percentChange.toFixed(1)}%
                      </div>
                      <div 
                        className={`w-full ${percentChange < 0 ? 'bg-green-500' : 'bg-blue-500'}`}
                        style={{ height: `${barHeight}%` }}
                      ></div>
                      <div className="text-xs font-medium mt-2 capitalize">
                        {key}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        
        {/* Progress Log */}
        <div>
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <div className="flex items-center mb-4">
              <Calendar size={20} className="mr-2 text-blue-600" />
              <h3 className="text-lg font-medium">Progress Log</h3>
            </div>
            
            <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
              {progressEntries.slice().reverse().map((entry, index) => (
                <div key={index} className="bg-white p-4 rounded border border-gray-200">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-medium">{new Date(entry.date).toLocaleDateString()}</div>
                    <div className="text-sm text-gray-500">
                      {entry.weight} kg {entry.bodyFat ? `| ${entry.bodyFat}% BF` : ''}
                    </div>
                  </div>
                  <p className="text-gray-700 text-sm mb-2">{entry.notes}</p>
                  
                  {entry.measurements && (
                    <div className="grid grid-cols-5 gap-2 mt-3 text-xs text-gray-500">
                      {Object.entries(entry.measurements).map(([key, value]) => (
                        value !== undefined && (
                          <div key={key} className="text-center">
                            <div className="font-medium capitalize">{key}</div>
                            <div>{value} cm</div>
                          </div>
                        )
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Add New Entry Form */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <Camera size={20} className="mr-2 text-blue-600" />
              <h3 className="text-lg font-medium">Add New Entry</h3>
            </div>
            
            <form onSubmit={handleAddEntry}>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    name="date"
                    value={newEntry.date}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Weight (kg)
                  </label>
                  <input
                    type="number"
                    name="weight"
                    value={newEntry.weight}
                    onChange={handleInputChange}
                    step="0.1"
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Body Fat % (optional)
                  </label>
                  <input
                    type="number"
                    name="bodyFat"
                    value={newEntry.bodyFat || ''}
                    onChange={handleInputChange}
                    step="0.1"
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  name="notes"
                  value={newEntry.notes}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  rows={2}
                ></textarea>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Measurements (cm, optional)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {['chest', 'waist', 'hips', 'arms', 'thighs'].map((part) => (
                    <div key={part}>
                      <label className="block text-xs text-gray-500 mb-1 capitalize">
                        {part}
                      </label>
                      <input
                        type="number"
                        name={part}
                        value={newEntry.measurements?.[part as keyof typeof newEntry.measurements] || ''}
                        onChange={handleMeasurementChange}
                        step="0.1"
                        className="w-full p-2 border border-gray-300 rounded-md"
                      />
                    </div>
                  ))}
                </div>
              </div>
              
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                Add Entry
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};