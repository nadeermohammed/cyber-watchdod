import React, { useState } from 'react';
import { ClientProfile } from '../App';

interface ClientProfileFormProps {
  clientProfile: ClientProfile | null;
  setClientProfile: (profile: ClientProfile) => void;
}

export const ClientProfileForm: React.FC<ClientProfileFormProps> = ({
  clientProfile,
  setClientProfile,
}) => {
  const [formData, setFormData] = useState<ClientProfile>(
    clientProfile || {
      name: '',
      age: 30,
      weight: 70,
      height: 170,
      gender: 'male',
      fitnessLevel: 'intermediate',
      dietaryRestrictions: [],
      goals: [],
      availableEquipment: [],
    }
  );

  const fitnessLevels = ['beginner', 'intermediate', 'advanced'];
  const dietaryRestrictionOptions = [
    'vegetarian',
    'vegan',
    'gluten-free',
    'dairy-free',
    'keto',
    'paleo',
  ];
  const goalOptions = [
    'weight loss',
    'muscle gain',
    'strength',
    'endurance',
    'flexibility',
    'general fitness',
  ];
  const equipmentOptions = [
    'none',
    'dumbbells',
    'barbell',
    'kettlebell',
    'resistance bands',
    'pull-up bar',
    'bench',
    'treadmill',
    'exercise bike',
    'full gym',
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleNumberChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: parseInt(value) || 0,
    });
  };

  const handleCheckboxChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    category: 'dietaryRestrictions' | 'goals' | 'availableEquipment'
  ) => {
    const { value, checked } = e.target;
    if (checked) {
      setFormData({
        ...formData,
        [category]: [...formData[category], value],
      });
    } else {
      setFormData({
        ...formData,
        [category]: formData[category].filter((item) => item !== value),
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setClientProfile(formData);
    alert('Client profile saved successfully!');
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Client Profile</h2>
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Client Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Age
            </label>
            <input
              type="number"
              name="age"
              value={formData.age}
              onChange={handleNumberChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              min="1"
              max="120"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Weight (kg)
            </label>
            <input
              type="number"
              name="weight"
              value={formData.weight}
              onChange={handleNumberChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              min="1"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Height (cm)
            </label>
            <input
              type="number"
              name="height"
              value={formData.height}
              onChange={handleNumberChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              min="1"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Gender
            </label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              required
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Fitness Level
            </label>
            <select
              name="fitnessLevel"
              value={formData.fitnessLevel}
              onChange={handleInputChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              required
            >
              {fitnessLevels.map((level) => (
                <option key={level} value={level}>
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Dietary Restrictions
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {dietaryRestrictionOptions.map((restriction) => (
              <div key={restriction} className="flex items-center">
                <input
                  type="checkbox"
                  id={`restriction-${restriction}`}
                  value={restriction}
                  checked={formData.dietaryRestrictions.includes(restriction)}
                  onChange={(e) => handleCheckboxChange(e, 'dietaryRestrictions')}
                  className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
                <label
                  htmlFor={`restriction-${restriction}`}
                  className="ml-2 text-sm text-gray-700"
                >
                  {restriction.charAt(0).toUpperCase() + restriction.slice(1)}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fitness Goals
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {goalOptions.map((goal) => (
              <div key={goal} className="flex items-center">
                <input
                  type="checkbox"
                  id={`goal-${goal}`}
                  value={goal}
                  checked={formData.goals.includes(goal)}
                  onChange={(e) => handleCheckboxChange(e, 'goals')}
                  className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
                <label
                  htmlFor={`goal-${goal}`}
                  className="ml-2 text-sm text-gray-700"
                >
                  {goal.charAt(0).toUpperCase() + goal.slice(1)}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Available Equipment
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {equipmentOptions.map((equipment) => (
              <div key={equipment} className="flex items-center">
                <input
                  type="checkbox"
                  id={`equipment-${equipment}`}
                  value={equipment}
                  checked={formData.availableEquipment.includes(equipment)}
                  onChange={(e) => handleCheckboxChange(e, 'availableEquipment')}
                  className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
                <label
                  htmlFor={`equipment-${equipment}`}
                  className="ml-2 text-sm text-gray-700"
                >
                  {equipment.charAt(0).toUpperCase() + equipment.slice(1)}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8">
          <button
            type="submit"
            className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Save Client Profile
          </button>
        </div>
      </form>
    </div>
  );
};