import React, { useState } from 'react';
import { Code, Copy, Check, Terminal, Key, RefreshCw } from 'lucide-react';

export const APIIntegration: React.FC = () => {
  const [copied, setCopied] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState('sk_test_51HG8h2KJ3kl2Xas9iUY2bN7rP');
  const [showApiKey, setShowApiKey] = useState(false);
  
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };
  
  const regenerateApiKey = () => {
    // In a real app, this would call an API to regenerate the key
    setApiKey(`sk_test_${Math.random().toString(36).substring(2, 15)}`);
    alert('API key regenerated successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-6">API Integration</h2>
        
        <div className="mb-8">
          <p className="text-gray-700 mb-4">
            Integrate our face morphing detection capabilities directly into your applications using our REST API. 
            Send images or video frames and receive detailed analysis results.
          </p>
          
          <div className="flex items-center p-4 bg-yellow-50 text-yellow-800 rounded-lg">
            <Terminal size={20} className="mr-3 flex-shrink-0" />
            <p className="text-sm">
              Our API allows for up to 1,000 requests per month on the free tier. 
              For higher volume needs, please check our pricing page or contact sales.
            </p>
          </div>
        </div>
        
        {/* API Key Section */}
        <div className="mb-8">
          <h3 className="text-lg font-medium mb-4">Your API Key</h3>
          
          <div className="bg-gray-100 p-4 rounded-lg mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Key size={20} className="text-gray-500 mr-3" />
                <div>
                  <div className="text-sm text-gray-500 mb-1">API Key</div>
                  <div className="font-mono">
                    {showApiKey ? apiKey : apiKey.substring(0, 8) + '••••••••••••••••'}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="p-2 text-gray-500 hover:text-gray-700"
                >
                  {showApiKey ? 'Hide' : 'Show'}
                </button>
                <button
                  onClick={() => handleCopy(apiKey, 'apiKey')}
                  className="p-2 text-gray-500 hover:text-gray-700"
                >
                  {copied === 'apiKey' ? (
                    <Check size={18} className="text-green-500" />
                  ) : (
                    <Copy size={18} />
                  )}
                </button>
                <button
                  onClick={regenerateApiKey}
                  className="p-2 text-gray-500 hover:text-gray-700"
                  title="Regenerate API Key"
                >
                  <RefreshCw size={18} />
                </button>
              </div>
            </div>
          </div>
          
          <div className="text-sm text-gray-500">
            <p>Keep your API key secure! Do not share it in publicly accessible areas such as GitHub, client-side code, etc.</p>
          </div>
        </div>
        
        {/* Code Examples */}
        <div>
          <h3 className="text-lg font-medium mb-4">Code Examples</h3>
          
          <div className="space-y-6">
            {/* cURL Example */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">cURL</h4>
                <button
                  onClick={() => handleCopy(`curl -X POST \\
  https://api.facemorph-detect.io/v1/analyze \\
  -H "Authorization: Bearer ${apiKey}" \\
  -F "image=@/path/to/image.jpg" \\
  -F "detection_level=high"`, 'curl')}
                  className="text-purple-600 text-sm flex items-center"
                >
                  {copied === 'curl' ? (
                    <>
                      <Check size={16} className="mr-1" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={16} className="mr-1" />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                <pre className="text-sm">
                  <code>{`curl -X POST \\
  https://api.facemorph-detect.io/v1/analyze \\
  -H "Authorization: Bearer ${apiKey}" \\
  -F "image=@/path/to/image.jpg" \\
  -F "detection_level=high"`}</code>
                </pre>
              </div>
            </div>
            
            {/* Python Example */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">Python</h4>
                <button
                  onClick={() => handleCopy(`import requests

url = "https://api.facemorph-detect.io/v1/analyze"
headers = {
    "Authorization": f"Bearer ${apiKey}"
}

files = {
    "image": open("path/to/image.jpg", "rb")
}

data = {
    "detection_level": "high"
}

response = requests.post(url, headers=headers, files=files, data=data)
result = response.json()

print(result)`, 'python')}
                  className="text-purple-600 text-sm flex items-center"
                >
                  {copied === 'python' ? (
                    <>
                      <Check size={16} className="mr-1" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={16} className="mr-1" />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                <pre className="text-sm">
                  <code>{`import requests

url = "https://api.facemorph-detect.io/v1/analyze"
headers = {
    "Authorization": f"Bearer ${apiKey}"
}

files = {
    "image": open("path/to/image.jpg", "rb")
}

data = {
    "detection_level": "high"
}

response = requests.post(url, headers=headers, files=files, data=data)
result = response.json()

print(result)`}</code>
                </pre>
              </div>
            </div>
            
            {/* JavaScript Example */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">JavaScript</h4>
                <button
                  onClick={() => handleCopy(`const form = new FormData();
form.append('image', imageFile);
form.append('detection_level', 'high');

fetch('https://api.facemorph-detect.io/v1/analyze', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ${apiKey}'
  },
  body: form
})
.then(response => response.json())
.then(result => {
  console.log(result);
})
.catch(error => {
  console.error('Error:', error);
});`, 'javascript')}
                  className="text-purple-600 text-sm flex items-center"
                >
                  {copied === 'javascript' ? (
                    <>
                      <Check size={16} className="mr-1" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={16} className="mr-1" />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                <pre className="text-sm">
                  <code>{`const form = new FormData();
form.append('image', imageFile);
form.append('detection_level', 'high');

fetch('https://api.facemorph-detect.io/v1/analyze', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ${apiKey}'
  },
  body: form
})
.then(response => response.json())
.then(result => {
  console.log(result);
})
.catch(error => {
  console.error('Error:', error);
});`}</code>
                </pre>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* API Documentation */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium">API Documentation</h3>
          <a 
            href="#" 
            className="text-purple-600 flex items-center hover:text-purple-800"
          >
            <Code size={18} className="mr-2" />
            Full Documentation
          </a>
        </div>
        
        <div className="space-y-6">
          <div>
            <h4 className="font-medium mb-2">Endpoints</h4>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Endpoint
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Method
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    /v1/analyze
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    POST
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    Analyze an image for face morphing and manipulation
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    /v1/video/analyze
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    POST
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    Analyze a video for face morphing and manipulation
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    /v1/batch
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    POST
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    Submit multiple images for batch analysis
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div>
            <h4 className="font-medium mb-2">Response Format</h4>
            <div className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
              <pre className="text-sm">
                <code>{`{
  "id": "scan-123456",
  "timestamp": "2025-01-07T14:32:45Z",
  "threat_score": 87,
  "manipulation_probability": 0.92,
  "manipulation_types": {
    "face_swap": 0.15,
    "morphing": 0.85,
    "synthesis": 0.32,
    "attributes": 0.12
  },
  "regions": [
    {
      "x": 120,
      "y": 80,
      "width": 100,
      "height": 100,
      "confidence": 0.92,
      "type": "morphing"
    }
  ]
}`}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};